paper name-
C.H. Liu, Y. Qi, W.R. Ding. Infrared and visible image fusion method based on saliency detection in sparse domain[J]. Infrared Physics & Technology.

DIctionary for each source images are stored in file 'dictionary'.

JSR   - fusion_JSR.m
JSRSD - fusion_JSRSD.m


For new source images to fused, you need matlab tool boxes - 'ksvd' and 'omp'.


